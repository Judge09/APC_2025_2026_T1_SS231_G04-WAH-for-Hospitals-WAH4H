# Django management module
